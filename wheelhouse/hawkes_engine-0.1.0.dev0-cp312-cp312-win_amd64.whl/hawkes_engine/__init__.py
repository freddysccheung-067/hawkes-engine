"""Multi-dimensional Hawkes process library with trust calibration.

Pre-alpha. The compiled likelihood and its gradient are in place, as is the
maximum-likelihood estimator with its standard errors and its reliability
verdict. The simulators and the calibration map land over gates H4-H6. See
docs/ROADMAP.md.
"""


# start delvewheel patch
def _delvewheel_patch_1_13_2():
    import os
    if os.path.isdir(libs_dir := os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'hawkes_engine.libs'))):
        os.add_dll_directory(libs_dir)


_delvewheel_patch_1_13_2()
del _delvewheel_patch_1_13_2
# end delvewheel patch

from hawkes_engine._core import build_info
from hawkes_engine.diagnostics import ks_test, ljung_box, qq_data, time_rescale
from hawkes_engine.fit import fit
from hawkes_engine.loglik import LoglikResult, loglik, loglik_grad_log_space
from hawkes_engine.model import FitResult
from hawkes_engine.simulation import simulate, simulate_many

__version__ = "0.1.0.dev0"
__license__ = "MIT"

__all__ = [
    "__version__",
    "build_info",
    "fit",
    "FitResult",
    "loglik",
    "loglik_grad_log_space",
    "simulate",
    "simulate_many",
    "time_rescale",
    "ks_test",
    "ljung_box",
    "qq_data",
    "LoglikResult",
]
